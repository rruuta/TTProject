package com.example.tttproject
// konstantes spēles rezultātiem
const val P1_uzvar = "%s uzvarēja!"
const val P2_uzvar = "%s uzvarēja!"
const val Neizskirts = "Neizšķirts"

//iestata visus datus spēles stāvoklim, spēlētājus, lauku, gājienu, rezultātu
data class GameState(
    val s1Vards: String = "1. Spēlētājs",
    val s2Vards: String = "2. Spēlētājs",
    val greeting: String = "Tu spēlē manu pirmo android spēli!",
    val board: IntArray = IntArray(9) { -1 },
    val aktspeletajs: Int = 0,
    val spelenotiek: Boolean = true,
    val rezultats: String? = null
)

//nosaka spēles mode
enum class GameMode { PVP, PVC }

// vislaik atjaunojam spēles stāvokli pēc katra gājiena
fun makeMove(state: GameState, i: Int) = if (!state.spelenotiek || state.board[i] != -1) state else {
    val board = state.board.copyOf().apply {
        this[i] = state.aktspeletajs
    }
    //nosaka aktīvo spēlētāju, pārbauda gājiena derīgumu un vai ir spēles beigas ar funkciju checkWinner
    val result = checkWinner(board, state.s1Vards, state.s2Vards)
    state.copy(
        board = board,
        aktspeletajs = 1 - state.aktspeletajs,
        spelenotiek = result == null,
        rezultats = result
    )
}

// atbild par datora gājieniem
fun computerMove(state: GameState) = if (!state.spelenotiek || state.aktspeletajs != 1)
    state else {
        // ja dators nav kā aktīvs spēlētājs, atgriež pašreizējo spēles stāvokli
    val empty = state.board.indices.filter { state.board[it] == -1 }
    if (empty.isEmpty())
        // ja dators ir aktīvs spēlētājs, tas izvēlas jebkādu lauciņu gājienam
        state else makeMove(state, empty.random())
}
// nosaka uzvarētāju
fun checkWinner(board: IntArray, p1: String, p2: String): String? {
    val uzvPoz = arrayOf(
        // uzvaras pozīcijas masīvā
        intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
        intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
        intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
    )
    //cikls lauciņu un uzvaras pozīciju pārbaudei
    for (poz in uzvPoz) {
        val (a, b, c) = poz
    // nosaka vai pozīcijas aizpildītas ar vienādiem simboliem vai arī ir tukšas
        if (board[a] == board[b] && board[b] == board[c] && board[a] != -1) {
            return if (board[a] == 0) P1_uzvar.format(p1) else P2_uzvar.format(p2)
        }
    }
    // nosaka vai visi lauciņi aizpildīti ar dažādiem simboliem un izvada neizšķirtu,
    return if (board.all { it != -1 }) Neizskirts else null
}


