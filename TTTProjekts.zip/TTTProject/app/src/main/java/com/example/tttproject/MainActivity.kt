package com.example.tttproject
// importi
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.tttproject.ui.theme.TttprojectTheme

//Definē galveno klasi
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        // funkcija kas tiek izsaukta, kad spēle tiek pirmo reizi izveidota, atver iepriekšejo stāvokli ja tāds bijis
        super.onCreate(savedInstanceState)
        setContent { // iestata spēles saturu, spēlētājus, pvp vai pvc, pašreizējo spēles stāvokli un to vai spēle ir sākusies
            TttprojectTheme {
                var p1Vards by remember {
                    mutableStateOf("")
                }
                var p2Vards by remember {
                    mutableStateOf("")
                }
                var mode by remember {
                    mutableStateOf<GameMode?>(null)
                }
                var stavoklis by remember {
                    mutableStateOf(GameState())
                }
                var sakums by remember {
                    mutableStateOf(false)
                }

                if (!sakums) { //nosaka vai spēle sākusies
                    SetupScreen( //pirms spēles sākuma, izvada logu, kurā spēlētāji saraksta vārdus un izvēlas pvp vai pvc
                        p1Vards, p2Vards, mode,
                        { p1Vards = it }, { p2Vards = it }, { mode = it },
                        {
                            sakums = true
                            stavoklis = GameState(
                                s1Vards = p1Vards,
                                s2Vards = if (mode == GameMode.PVC) "Computer" else p2Vards
                            )
                        }
                    )
                } else {
                    GameScreen(
                        //spēlei sākoties, nosaka vai spēlē pret datoru, iestata mainīgo isComputer
                        stavoklis,
                        isComputer = mode == GameMode.PVC,
                        // funkcija kas atbild par izmaiņām pēc spēlētāja veiktā gājiena
                        onMove = { i -> stavoklis = makeMove(stavoklis, i).let{ new ->
                                if (mode == GameMode.PVC && new.spelenotiek && new.aktspeletajs == 1) computerMove(new)
                                else new
                            }
                        },
                        onReset = { // var sākt spēli no jauna, saglabājot spēlētājus
                            sakums = false
                            p1Vards = ""
                            p2Vards = ""
                            mode = null
                            stavoklis = GameState()
                        },
                        onPlayAgain = { // var sākt spēli no jauna, ievadot jaunus vārdus un mode
                            stavoklis = GameState(s1Vards = stavoklis.s1Vards, s2Vards = stavoklis.s2Vards)
                        }
                    )
                }
            }
        }
    }
}