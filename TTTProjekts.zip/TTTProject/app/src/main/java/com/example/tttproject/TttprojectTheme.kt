package com.example.tttproject.ui.theme
//importi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

// nosaka krāsu shēmu spēlei, pogām, fonam
private val LightColorScheme = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFFD5006D),
    secondary = androidx.compose.ui.graphics.Color(0xFF4F87E5),
    background = androidx.compose.ui.graphics.Color.White,
    surface = androidx.compose.ui.graphics.Color.White,
    onPrimary = androidx.compose.ui.graphics.Color.Black,
    onSecondary = androidx.compose.ui.graphics.Color.Black,
    onBackground = androidx.compose.ui.graphics.Color.White,
    onSurface = androidx.compose.ui.graphics.Color.Black
)
// krāsu shēmu piešķir pilnīgi visai spēlei
@Composable
fun TttprojectTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}