package com.example.tttproject
// importi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// pirms spēles sākuma, parametri vārdu ievadei, mode izvēlei utt
@Composable
fun SetupScreen(
    p1Vards: String,
    p2Vards: String,
    mode: GameMode?,
    onP1NameChange: (String) -> Unit,
    onP2NameChange: (String) -> Unit,
    onMode: (GameMode) -> Unit,
    onSakums: () -> Unit
) {
    // vizuālais izskats, un divu spelētāju vārdu ievade, ja jāievada vārds, tad lauks ir ar spilgtu apmali
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Tic-Tac-Toe", fontSize = 26.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(p1Vards, onP1NameChange, label = { Text("1. Spēlētājs") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Row {
            Button( {
                // mode izvēlei pievienotas pogas, kuras arī spīd brīdī kad ir piespiestas
                    onMode(GameMode.PVP)
                },
                Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (mode == GameMode.PVP) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (mode == GameMode.PVP) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Text("PvP")
            }
            Spacer(Modifier.width(10.dp))
            Button(
                // // mode izvēlei pievienotas pogas, kuras arī spīd brīdī kad ir piespiestas
                {
                    onMode(GameMode.PVC)
                },
                Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (mode == GameMode.PVC) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (mode == GameMode.PVC) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Text("PvC")
            }
        }
        if (mode == GameMode.PVP) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(p2Vards, onP2NameChange, label = { Text("2. Spēlētājs") }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(10.dp))
        Button(
            // parametri, kas nosaka ka pogu sākt var piespiest tikai pēc vārdu ievades un mode izvēles
            onSakums,
            enabled = p1Vards.isNotBlank() && mode != null && (mode == GameMode.PVC || p2Vards.isNotBlank())
        ) {
            Text("Sākt")
        }
    }
}

// spēlei sākoties, galvenais ekrāns
@Composable
fun GameScreen(
    state: GameState,
    isComputer: Boolean,
    onMove: (Int) -> Unit,
    onReset: () -> Unit,
    onPlayAgain: () -> Unit
) {
    // vizuālais izskats, norāda kura spēlētāja gājiens
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(state.greeting, fontSize = 22.sp)
        Spacer(Modifier.height(10.dp))
        if (state.spelenotiek) {
            Text("Gājiens: ${if (state.aktspeletajs == 0) state.s1Vards else state.s2Vards}", fontSize = 20.sp)
        }
        // spēles lauks, norāda kur tieši ir katrs spēles lauks
        Spacer(Modifier.height(14.dp))
        Column {
            for (r in 0..2) {
                Row {
                    for (c in 0..2) {
                        val i = r * 3 + c
                        Box(
                            Modifier
                                .size(80.dp)
                                .border(1.dp, Color.Black)
                                .background(Color.White)
                                .clickable(state.spelenotiek && state.board[i] == -1) { onMove(i) },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                //ja brīvs lauciņs, tad norāda, ka var veikt gājienu
                                when (state.board[i]) {
                                    0 -> "O"
                                    1 -> "X"
                                    else -> ""
                                },
                                fontSize = 34.sp,
                                color = Color.Black
                            )
                        }
                    }
                }
            }
        }
    }

    // 
    if (state.rezultats != null) {
        AlertDialog(
            onDismissRequest = {},
            title = {
                Text("Rezultāts")
                    },
            text = {
                Text(state.rezultats)
                   },
            confirmButton = {
                TextButton(onClick = onPlayAgain) { Text("Spēlēt vēlreiz") } },
            dismissButton = {
                TextButton(onClick = onReset) { Text("Atpakaļ uz sākumu") } }
        )
    }
}